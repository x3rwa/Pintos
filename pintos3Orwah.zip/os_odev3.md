---- GRUP ----

>> Grubunuzun üyelerinin isimlerini ve e-posta adreslerini giriniz.

ORWAH NJJAR (2022280019@ogr.deu.edu.tr)
CANER MUTLU (2023280045@ogr.deu.edu.tr)

---- ÖN HAZIRLIKLAR ----

>> Gönderiminizle ilgili herhangi bir ön yorumunuz, TA'lar için notlarınız veya ek kredi talepleriniz varsa, lütfen burada belirtin.

Bu projeyi tamamen kendi başıma çalıştım. Proje grup çalışması olarak verilmiş olsa da, maalesef grup arkadaşlarımdan yardım alamadım. Bu nedenle, teslimimde herhangi bir eksiklik veya hata görülürse, lütfen bunu yalnız çalışmak zorunda kalmış olmama bağlı olarak değerlendirmenizi rica ederim. Saygılarımla.

>> Gönderiminizi hazırlarken Pintos belgeleri, ders kitabı, ders notları ve kurs personeli dışında başvurduğunuz her türlü çevrimdışı veya çevrimiçi kaynağı belirtin.

Projeyi hazırlarken, YouTube'da Pintos projesi hakkında açıklamalar yapan bir kanaldan faydalandım. Ayrıca bazı hataları çözmek için ChatGPT ve Stack Overflow platformlarını da kullandım.

---- VERİ YAPILARI ----

>> A1: Her yeni veya değişen `struct` veya `struct` üyesinin, küresel veya statik değişkenin, `typedef`'in veya enum'un deklarasyonunu buraya yapıştırın. Her birinin amacını 25 kelimeyle açıklayın.

/* Ek sayfa tablosundaki bir giriş. */
struct supp_page {
  void *user_page;                 // Kullanıcı sanal adresi (sayfa hizalı)
  struct frame *frame;            // Sayfa yüklüyse, ona karşılık gelen çerçeve
  bool writable;                  // Sayfa yazılabilir mi?
  enum page_location {
    IN_FRAME,                     // Sayfa RAM'de (çerçevede)
    IN_SWAP,                      // Sayfa takasta
    IN_FILESYS,                   // Sayfa dosya sisteminde
    ALL_ZERO                      // Sayfa sıfırlarla dolu
  } location;                     // Sayfanın bulunduğu yer
  size_t swap_index;             // Takastaki slot indeksi
  struct file *file;             // Dosya eşlemeli sayfalar için dosya işaretçisi
  off_t file_offset;             // Dosya içindeki başlangıç ofseti
  size_t read_bytes;             // Dosyadan okunacak bayt sayısı
  size_t zero_bytes;             // Sıfırlanacak bayt sayısı
  struct hash_elem hash_elem;    // Hash tablosu için eleman

  bool is_mmap;                  // mmap dosyası mı?
};

Her kullanıcı sanal sayfası için, bu yapı sayfanın bulunduğu yeri, dosya bilgilerini ve takas indeksini takip eder. Sayfa hatası çözümünde kullanılır.


---- ALGORİTMALAR ----

>> A2: Verilen bir sayfa hakkında SPT'de saklanan verilere erişmek için yazdığınız kodu birkaç paragraf ile açıklayın.

Supplemental Page Table (SPT), bir kullanıcının sayfa bilgilerini izlemek için kullanılan hash tabanlı veri yapısıdır. Sayfa hatası meydana geldiğinde, page_fault() fonksiyonu bu tabloyu kullanarak ilgili sayfanın bilgilerine erişir.

Kod genellikle şu adımlarla çalışır:

1-Sanal adresi alır (örneğin fault_addr).
2-Adresi sayfa hizasına yuvarlar (örneğin pg_round_down() kullanılarak).
3-Bu adresi temel alarak geçici bir supp_page yapı örneği oluşturur.
4-hash_find() fonksiyonu ile hash tablosunda arama yapılır.
5-Eğer bir eşleşme bulunursa, fonksiyon bu yapının pointer’ını döner ve işlem devam eder.

Bu erişim şekli sayesinde, sayfa sisteminin durumu (RAM'de mi, swap'te mi, dosyadan mı geliyor) belirlenip uygun yükleme stratejisi uygulanır.

>> A3: Kodunuz, birden fazla sanal adresi birleştiren bir çerçeveye ait erişilmiş ve kirli bitlerini çekirdek ve kullanıcı sanal adresleri arasında nasıl koordine ediyor ya da bu sorundan nasıl kaçınıyor?

Pintos'ta aynı fiziksel çerçeveye iki sanal adres eşleştirilebilir: biri kullanıcı adresi (user_page), diğeri çekirdek alias’ı (kernel_page). Bu durum erişim ve kirli bitlerinin yalnızca bir adres için güncellenmesine neden olur.

Çözüm yolları:
1-Biz sadece kullanıcı sanal adresi üzerinden erişim yapıyoruz. Böylece sadece tek bir PTE (Page Table Entry) izleniyor ve alias sorunundan kaçınılıyor.
2-Sayfa değiştirme algoritması (örneğin saat algoritması) bu kullanıcı adresinden pagedir_is_accessed() ve pagedir_is_dirty() fonksiyonlarını çağırarak bitleri kontrol ediyor.
3-Bu bitler kontrol edildikten sonra sıfırlanır (reset) ve erişim/kirlilik durumu güncellenir.

Sonuç olarak:
Alias çakışmalarını engellemek için çekirdek erişimlerini daima user_page üzerinden yapıyoruz. Böylece erişilmiş ve kirli bitleri doğru şekilde izlenebiliyor.

---- SENKRONİZASYON ----

>> A4: İki kullanıcı süreci aynı anda yeni bir çerçeveye ihtiyaç duyduğunda, yarışlar nasıl önleniyor?

Bu tür yarış koşulları (race condition), çerçeve tablosuna erişim sırasında çok kritik hale gelir. Aynı anda iki thread (veya işlem) yeni bir çerçeve tahsis etmek isterse, aşağıdaki yöntemlerle senkronizasyon sağlanır:

Kilit (lock) kullanımı:
Tüm frame_table erişimleri (ekleme, çıkarma, seçim, güncelleme) tek bir global frame_table_lock ile korunur. Bu lock:
1-frame_alloc() gibi çerçeve tahsis fonksiyonlarına yerleştirilir.
2-Aynı anda yalnızca bir thread’in çerçeve aramasına veya çerçeve tablosunu değiştirmesine izin verir.

Eviction (çerçeve boşaltma) sırasında:
1-Boş çerçeve yoksa, page eviction algoritması çalıştırılır.
2-Aynı anda birden fazla thread eviction yapmaya çalışmasın diye bu da lock altında yapılır.
palloc_get_page(PAL_USER) çağrısı sonrası frame tablosuna yapılan erişimler ve güncellemeler, mutual exclusion (karşılıklı dışlama) garantisi altındadır. Böylece yarış koşulları tamamen engellenir.

---- GEREKÇE ----

>> A5: Sanal-fizik eşlemelerini temsil etmek için neden seçtiğiniz veri yapısını seçtiniz?

               SAYFALAMA İŞLEMLERİ VE DİSKE YAZMA
               =======================

Seçilen yapı: Hash Table (struct hash)
Dosya: vm/page.c içinde uygulanır.

Neden hash table seçtik?
1-Hızlı erişim:
Sayfa hatası meydana geldiğinde, ilgili sanal adresin bilgisini hızlıca bulmamız gerekir. Hash table'da arama (O(1) ortalama karmaşıklık), liste veya diziye göre çok daha hızlıdır.

2-Seyrek adresleme desteği:
Kullanıcı adres uzayı büyük ve seyrek (örneğin 0x08048000 adresinde bir sayfa olabilir, ama 0x08049000 boş olabilir). Hash table, sadece kullanılan sayfaları saklar, bellek israfı yapmaz.

3-Sayfalama işlemleriyle uyumlu:
Hash table sayesinde her sayfanın durumu (RAM’de mi, swap’te mi, sıfır mı, dosyadan mı geliyor) ayrı bir girişte tutulabilir. Böylece:
Lazy loading (tembel yükleme),
Swap-out / Swap-in,
mmap gibi farklı senaryolar kolayca takip edilir.

4-Kolay genişleme ve silme:
Sayfa tahsisi veya serbest bırakma sırasında, hash_insert, hash_delete kullanılarak kolayca güncellenebilir.

---- VERİ YAPILARI ----

>> B1: Her yeni veya değişen `struct` veya `struct` üyesinin, küresel veya statik değişkenin, `typedef`'in veya enum'un deklarasyonunu buraya yapıştırın. Her birinin amacını 25 kelimeyle açıklayın.

/* Çerçeve tablosundaki bir giriş. */
struct frame {
  void *kpage;                     // Çekirdek sanal adresi (çerçevenin başlangıcı)
  struct supp_page *spte;         // Bu çerçevede yüklü olan sayfanın SPT girişi
  struct thread *owner;           // Çerçeveyi kullanan işlem
  struct list_elem elem;          // frame_table içinde kullanılacak liste elemanı
  bool pinned;                    // Bu çerçeve sabitlenmişse (swap edilemez)
};

Bu yapı, bellekteki bir fiziksel çerçeveyi temsil eder. Hangi işlemin ve hangi sanal sayfanın kullandığını izleyerek sayfa değiştirme ve senkronizasyonu yönetir.

---- ALGORİTMALAR ----

>> B2: Bir çerçeve gerektiğinde ancak boşta bir çerçeve bulunamadığında, hangi çerçevenin çıkarılacağını seçen kodu açıklayın.

Bu işlem, page replacement (sayfa çıkarma) algoritması ile yapılır. Genellikle kullanılan algoritma:

"Clock" (ikinci şans) algoritmasıdır:

1-frame_table bir liste (veya dairesel yapı) şeklinde tutulur.
2-Her çerçeveye bir “ikinci şans” verilir. Bu, sayfanın "accessed" (erişildi) bitiyle izlenir.
3-Algoritma sıradaki çerçeveyi kontrol eder:
    -Eğer accessed biti 1 ise, sıfırlanır ve sonraki çerçeveye geçilir.
    -Eğer accessed biti 0 ise, bu çerçeve çıkarılmak için seçilir.

for (;;) {
  if (!pagedir_is_accessed(owner->pagedir, upage)) {
    // Erişilmemişse çıkarılabilir
    return victim;
  } else {
    pagedir_set_accessed(owner->pagedir, upage, false);
    // İkinci şans verdik, sıradakine geç
  }
}


>> B3: Bir işlem P, daha önce bir işlem Q tarafından kullanılan bir çerçeveyi elde ettiğinde, sayfa tablosunu (ve diğer veri yapılarını) nasıl ayarlarsınız? Q'nun artık bu çerçeveye sahip olmadığını nasıl belirlersiniz?

İşlem P, eviction işlemi sonucunda Q'nun bir çerçevesini alırsa, şu adımlar izlenir:

1-Q'nun sayfası SPT'ye yazılır:
    -Eğer sayfa kirli ise, veriler ya dosyaya ya da swap alanına yazılır.
    -spte->location = IN_SWAP; ve spte->swap_index = x; gibi bilgiler güncellenir.

2-Q'nun sayfa tablosu temizlenir:
    -pagedir_clear_page(q->pagedir, spte->user_page);
    -Böylece Q artık bu fiziksel çerçeveyi kullanamaz.

3-Frame tablosu güncellenir:
    -frame->owner = current_thread;
    -frame->spte = current_thread’ün ilgili supp_page girdisiyle değiştirilir.

4-Yeni sayfa (P’nin) çerçeveye yüklenir:
    -Eğer dosyadan geliyorsa, diskteki ilgili baytlar okunur.
    -Eğer sıfır sayfasıysa, memset ile sıfırlanır.
    -pagedir_set_page() ile P’nin page table’ına fiziksel çerçeve bağlanır.

Q'nun artık bu çerçeveye sahip olmadığı nasıl anlaşılır?
    -Q’nun page table’ından çerçeve referansı kaldırılmıştır.
    -frame->owner ve frame->spte artık P’yi gösterir.
    -frame_table'daki liste güncellenmiştir.
    -Evicted sayfanın SPT’si IN_SWAP gibi yeni konumla işaretlenmiştir.

>> B4: Hatalı bir sanal adres için sayfa hatası, yığın uzatılmasına neden olup olmayacağını belirlemek için kullandığınız heuristiği açıklayın.

Yığın büyümesi kararı için kullandığımız heuristik (yaklaşım) şudur:
Heuristik koşullar:

1-Adres esp'den küçük olmalı, yani erişilmeye çalışılan adres mevcut stack pointer’dan daha düşük olmalı.
2-Adres, esp’nin en fazla 32 bayt altına kadar düşebilir. Bu, PUSHA gibi talimatların 32 bayt altına erişebilmesi için gereklidir.
3-Adres, kullanıcı sanal adres alanında ve PHYS_BASE’in altında olmalı.
4-Yığın sınırı aşılmamalı. Örneğin, maksimum 8 MB sınırı konulabilir.

Kod örneği :
if (fault_addr >= esp - 32 && fault_addr >= USER_STACK_BOTTOM && fault_addr < PHYS_BASE)
  // sayfa yığını uzatmak için tahsis edilir


---- SENKRONİZASYON ----

>> B5: VM senkronizasyon tasarımınızın temellerini açıklayın. Özellikle, ölü kilitlenmeyi nasıl önlediğini açıklayın. (Ölü kilitlenme için gerekli koşullar hakkında ders kitabına bakın.)

VM sisteminde birçok kaynak paylaşıldığı için senkronizasyon hayati önem taşır.

Kullandığımız kilitler:
-frame_table_lock: Çerçeve tablosuna erişim için
-swap_lock: Swap işlemleri sırasında
-file_lock: mmap veya lazy loading sırasında dosya okuma/yazma için

Ölü kilitlenme (deadlock) dört koşulu içerir:
1-Karşılıklı dışlama
2-Tutan ve bekleyen
3-Öncelik yok
4-Döngüsel bekleme

Tasarımımız bu koşulları nasıl önler:

    -Sabit kilit alma sırası: Tüm işlemler her zaman aynı sırayla kilit alır. Örneğin:
    frame_table_lock → swap_lock → file_lock. Bu, döngüsel beklemeyi engeller.

    -Kilitler kısa tutulur: Uzun süreli işlemler (I/O gibi) kilit dışına alınır.

    -Sabitlenmiş (pinned) çerçeveler: Sayfa dışarı atılamayacaksa pinned = true yapılır, böylece erişim sırasında swap yarışları engellenir.

    -Koşul değiştiğinde kilit bırakılır: Örneğin, swap yetersizse veya başka işlemle çakışma varsa, işlem yeniden denenmek üzere kilidi bırakıp geri döner.

>> B6: Bir işlem P'deki sayfa hatası başka bir işlem Q'nun çerçevesinin çıkarılmasına neden olabilir. Q'nun sayfa çıkarılma sürecinde sayfayı erişememesini veya değiştirmemesini nasıl sağlarsınız? P'nin Q'nun çerçevesini çıkarması ile Q'nun sayfayı tekrar yüklemesi arasında nasıl bir yarış önlersiniz?

Bu durumda iki önemli senaryo var:

1-Q’nun sayfayı kullanırken P onu çıkarmaya çalışıyor
Çözüm: "pinned" bayrağı
    -Her çerçevede bool pinned vardır.
    -Sayfaya aktif erişim varsa (file_read, mmap erişimi, system call kopyalama), pinned = true yapılır.
    -Page replacement algoritması, pinned == true olan çerçeveleri asla dışarı atmaz.
    -Böylece Q’nun aktif kullandığı sayfa asla ortadan kaldırılmaz.

2-P, çerçeveyi çıkardıktan sonra Q tekrar erişmek isterse
Çözüm: SPT senkronizasyonu ve swap/index bilgisi
    -Çıkarılan sayfanın spte->location = IN_SWAP olarak güncellenir.
    -Sayfa Q tarafından tekrar talep edilirse, SPT bilgisi kullanılarak swap’ten geri yüklenir.
    -frame_table_lock gibi senkronizasyon yapıları sayesinde çerçeve henüz boşaltılırken başka işlem tekrar yükleme başlatamaz.

Yarış önleyici özet:
    -SPT güncellenmeden frame çerçevesi boşaltılmaz.
    -frame->pinned koruma sağlar.
    -frame_table_lock ile eviction ve yeniden erişim atomik olur.

>> B7: Bir işlem P'deki sayfa hatası bir sayfanın dosya sisteminden veya takas alanından okunmasına neden olduğunda, ikinci bir işlem Q'nun bu çerçeveyi çıkarmaya çalışarak müdahale etmesini nasıl engellersiniz?

Bir işlem P'deki sayfa hatası, bir sayfanın dosya sisteminden veya takas alanından okunmasına neden olduğunda, ikinci bir işlem Q'nun bu çerçeveyi çıkarmaya çalışmasını nasıl engellersiniz?

-P işlemi bir sayfa hatası aldığında, ilgili sayfa için yeni bir çerçeve (frame) tahsis edilir.
-Çerçeve tahsis edildikten hemen sonra, frame->pinned = true yapılır. Bu, çerçevenin sabitlendiği ve dışarı atılamayacağı anlamına gelir.
-Bu sayede, işlem Q veya başka bir işlem bu çerçeveyi page replacement (sayfa çıkarma) için seçemez.
-Sayfa belleğe yüklendikten ve page table güncellendikten sonra, pinned = false yapılır.
-Sayfa çıkarma algoritması (örneğin clock algoritması), sadece pinned == false olan çerçeveleri dikkate alır.
-Tüm bu işlemler sırasında frame_table_lock kullanılarak eşzamanlı erişimler kilitlenir ve yarış koşulları (race condition) önlenmiş olur.

>> B8: Sistem çağrıları sırasında sayfalanmış sayfalara erişimi nasıl ele alırsınız? Sayfaları geri getirmek için sayfa hatalarını mı kullanıyorsunuz (kullanıcı programlarında olduğu gibi), yoksa fiziksel belleğe çerçeveleri "kilitlemek" için bir mekanizma mı kullanıyorsunuz, yoksa başka bir tasarım mı kullanıyorsunuz? Geçersiz sanal adreslere yapılan erişimleri nasıl düzgün bir şekilde ele alıyorsunuz?

-read(), write() gibi sistem çağrıları, kullanıcıdan gelen bellek adreslerine erişmek isteyebilir.
-Bu adresler sayfalanmış ve şu anda bellekte bulunmuyor olabilir.
-Çekirdek modda sayfa hatasına izin verilmez, çünkü sürücüler reentrant değildir ve hatayı işleyemez.
-Bu nedenle, sistem çağrısı sırasında kullanıcı tamponu (buffer) verify_user() gibi bir fonksiyonla sayfa sayfa kontrol edilir.
-Eğer sayfa bellekte değilse, page fault handler kullanılarak manuel olarak sayfa belleğe getirilir.
-Sayfa yüklendikten sonra, ilgili frame->pinned = true yapılır ve I/O işlemi boyunca çerçevenin dışarı atılması engellenir.
-Sistem çağrısı tamamlandıktan sonra frame->pinned = false yapılarak normal dışarı atılabilir hale getirilir.
-Eğer adres geçersizse (örneğin PHYS_BASE üzerinde veya yazma izni olmayan sayfaya yazma girişimi varsa), işlem exit(-1) ile sonlandırılır.

---- GEREKÇE ----

>> B9: Tüm VM sistemi için tek bir kilit kullanmak senkronizasyonu kolaylaştırır, ancak paralellik sınırlıdır. Diğer taraftan, birden fazla kilit kullanmak senkronizasyonu karmaşıklaştırır ve ölü kilitlenme olasılığını artırır, ancak yüksek paralellik sağlar. Tasarımınızın bu uçlarda nerede olduğunu ve neden böyle bir tasarım yaptığınızı açıklayın.

             BELLEK HARİTA DOSYALARI
             ===================

Tasarımımız, tek bir global kilit kullanımı ile çok sayıda ince-granüllü kilit kullanımı arasında dengeli bir yerde konumlandırılmıştır. Yani tamamen tek kilit de kullanılmaz, her veri yapısı için ayrı karmaşık kilitler de değil; bunun yerine sınırlı ama işlevsel bir kilit bölümlendirmesi yapılmıştır.

1. Kullanılan kilitler:
    frame_table_lock: Tüm çerçeve tahsis ve çıkarma işlemleri için kullanılır.
    swap_lock: Takas alanına erişimi yönetmek için kullanılır.
    file_lock: Bellek eşlemeli dosyaların veya lazy loading işlemlerinde dosya erişimini korur.

Bu sayede her bir ana kaynak (frame, swap, dosya) için ayrı bir kilit tanımlanmıştır. Bu yapı:
    (a) Orta seviye paralellik sağlar. Örneğin bir işlem takasla uğraşırken diğeri frame tahsisi yapabilir.
    (b) Aynı anda farklı işlemlerin farklı veri yapılarıyla çalışmasına izin vererek sistem performansını artırır.

2. Neden bu tasarım tercih edildi:
    Tek bir global kilit kullanılsaydı, VM sisteminde her işlem birbirini bloklardı ve özellikle I/O ağır testlerde ciddi yavaşlamalar olurdu.
    Öte yandan, her sayfa ya da her çerçeve için ayrı kilitler tanımlamak, kilit sıralamasını kontrol etmeyi zorlaştırır ve ölü kilitlenme riskini artırırdı.
    Bu nedenle, kaynak başına bir kilit kullanarak, hem kod karmaşıklığını kontrol altında tutmak hem de yeterli düzeyde paralellik elde etmek hedeflenmiştir.

3. Ölü kilitlenme nasıl önlenir:
Tüm kilitler sabit bir sırayla alınır: önce frame_table_lock, sonra swap_lock, sonra file_lock.
    Sabit kilit sıralaması, döngüsel bekleme koşulunu ortadan kaldırır.
    Uzun sürecek işlemler yapılmadan önce kilitler serbest bırakılır veya pinleme uygulanarak sayfa koruma sağlanır.

4. Bellek haritalı dosyalar açısından:
    file_lock özellikle mmap() ve munmap() işlemleri sırasında eşzamanlı dosya erişimlerini kontrol etmek için önemlidir.
    Bu işlemler sırasında da aynı yukarıdaki kilit sıralamasına uyulur.

---- VERİ YAPILARI ----

>> C1: Her yeni veya değişen `struct` veya `struct` üyesinin, küresel veya statik değişkenin, `typedef`'in veya enum'un deklarasyonunu buraya yapıştırın. Her birinin amacını 25 kelimeyle açıklayın.

/* mmap için her eşlemeyi temsil eden yapı */
struct mmap_file {
  mapid_t mapid;                  // Eşleme kimliği (mmap çağrısından döner)
  struct file *file;             // Eşlenen dosyanın tekrar açılmış hali
  struct list page_list;         // Bu eşlemeyle ilgili tüm sayfaların listesi
  struct list_elem elem;         // process’in mmap listesi için eleman
};

/* mmap edilmiş her sayfa için SPT girdisine ek bilgi */
struct mmap_page {
  void *vaddr;                   // Kullanıcı sanal adresi
  size_t read_bytes;            // Dosyadan okunacak bayt sayısı
  size_t zero_bytes;            // Geri kalan kısmı sıfırlanacak bayt sayısı
  off_t offset;                 // Dosyadaki başlangıç ofseti
  bool writable;                // Sayfa yazılabilir mi?
  struct mmap_file *mmap_file;  // Ait olduğu mmap eşlemesi
  struct supp_page *spte;       // İlgili supplemental page table girdisi
  struct list_elem elem;        // mmap_file->page_list için liste elemanı
};

mmap_file, bir mmap eşlemesini izler; dosya referansı ve eşlenen sayfaları tutar. mmap_page, eşlenen her sayfanın konumunu ve durumunu temsil eder.

---- ALGORİTMALAR ----

>> C2: Bellek harita dosyalarının sanal bellek alt sisteminizle nasıl entegre olduğunu açıklayın. Sayfa hatası ve çıkarılma süreçlerinin takas sayfaları ve diğer sayfalar arasındaki farklarını açıklayın.

Bellek harita dosyaları (mmap) sanal bellek sistemine, her sayfa için supp_page girişi oluşturarak entegre olur. Bu girişlerde sayfanın dosyadan hangi offset’ten okunacağı, kaç bayt okunacağı ve sıfırlanacağı gibi bilgiler tutulur. Sayfalar başta yüklenmez, yalnızca erişildiğinde (lazy loading) dosyadan okunur.

Sayfa hatası olduğunda:
    mmap sayfası dosyadan okunur.
    swap sayfası ise takas alanından okunur.

Sayfa çıkarıldığında:
    mmap sayfası değişmişse dosyaya geri yazılır.
    swap sayfası ise swap alanına yazılır.

Yani mmap sayfaları dosya sistemiyle bağlıdır, swap sayfaları ise yalnızca RAM'den dışarı atılmak için kullanılır. Bu fark, geri yükleme ve temizlik işlemlerini de etkiler.

>> C3: Yeni bir dosya eşlemesinin mevcut bir segmentle örtüşüp örtüşmediğini nasıl belirlersiniz?

Yeni bir mmap eşlemesi yapılırken, verilen başlangıç adresinden itibaren eşlenecek her sayfa için kontrol yapılır. Bu sanal adreslerin her biri supp_page_table içinde aranır. Eğer bu adreslerden herhangi biri zaten mevcutsa (yani bir segment tarafından kullanılıyorsa), eşleme reddedilir. Bu şekilde yığın, kod segmenti veya başka bir mmap ile çakışma önlenmiş olur.

---- GEREKÇE ----

>> C4: "mmap" ile oluşturulan eşlemeler, veri talep sayfalaması ile benzer anlamlara sahiptir, ancak "mmap" eşlemeleri takasa değil, orijinal dosyalarına geri yazılır. Bu, bunların uygulamasının büyük ölçüde paylaşılabileceği anlamına gelir. Uygulamanızın, iki durum için kodu neden paylaşıp paylaşmadığını açıklayın.

Her iki durumda da sayfalar lazy loading ile yüklenir: yani sayfa sadece erişilince belleğe alınır. Bu yüzden dosyadan yüklenen sayfa türleri için page_fault() ve load_page_from_file() gibi işlemler ortak kullanılabilir.

Ancak fark şuradadır: mmap sayfaları değiştirilmişse dosyaya geri yazılır, talep sayfalamada ise swap’e yazılır. Bu fark nedeniyle çıkarma (eviction) ve temizlik (munmap) işlemleri ayrı kodlar içerir.

Yani yükleme aşamasında kod paylaşımı yapılabilir, ama çıkarma ve serbest bırakma aşamalarında ayrı işlemler gerekir. Bu yüzden sadece bazı bölümlerde kod paylaşımı yapılmıştır.
